<?php

namespace Webkul\Attribute\Contracts;

interface AttributeTranslation
{
}